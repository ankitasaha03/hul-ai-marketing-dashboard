# HUL AI Marketing Campaign Profitability & Budget Optimizer

Interactive GitHub Pages dashboard for an academic HUL marketing-budget optimization case study.

## Features
- Interactive media allocation sliders
- AI-style budget optimization using modeled ROAS weights
- Live spend, revenue, ROAS and media-waste KPIs
- Revenue-by-channel chart
- Spend vs revenue scatter plot
- ROAS distribution
- Campaign performance table
- CSV export
- Category selector
- Responsive design for laptop/mobile

## Run locally
Open `index.html` in a browser.

## GitHub Pages
1. Create a GitHub repository, for example `hul-ai-marketing-dashboard`.
2. Upload `index.html` and `README.md`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will provide your public Pages URL.

## Important
The dashboard uses illustrative/simulated case-study values. It is not an official HUL financial or campaign dataset.


## Chatbot
The dashboard includes a built-in **HUL Marketing AI Assistant**. It is client-side and API-free, so it works on GitHub Pages without exposing an API key. It answers questions from the live dashboard state, including channel ROAS, projected revenue, spend, budget allocation, and optimization logic.

For a production-grade generative AI chatbot, connect a secure backend/API rather than placing an OpenAI or Gemini secret key in browser JavaScript.
